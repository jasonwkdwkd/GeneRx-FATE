import csv
import gzip
import json
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
import generx_fate as gf

root = Path(__file__).resolve().parent


def read_lines(path):
    with gzip.open(path, 'rt') as handle:
        return handle.read().splitlines()


def reconstruct():
    metadata = pd.read_csv(root/'THP1.metadata.tsv.gz', sep='\t')
    assert metadata.index.is_unique
    labels = {
        cell: tuple(sorted(g for g in pair.split('_') if g != 'NT'))
        for cell, pair in metadata['GenePair'].items()
    }
    groups = sorted(set(labels.values()))
    lookup = {group: idx for idx, group in enumerate(groups)}
    counts, seen = Counter(), set()
    feature_ref, sums = None, None
    for lane in range(1, 5):
        prefix = f'THP1-CaRPool-seq_and_HEK293FTstabRNA.GEXGDO{lane}'
        raw = root/'raw'
        features = read_lines(raw/f'{prefix}.features.tsv.gz')
        if feature_ref is None:
            feature_ref = features
        assert features == feature_ref
        gene_count = sum(f.endswith('\tGene Expression') for f in features)
        assert all(f.endswith('\tGene Expression') for f in features[:gene_count])
        ids = [f'L{lane}_{c}' for c in read_lines(raw/f'{prefix}.barcodes.tsv.gz')]
        matched = {cell for cell in ids if cell in labels}
        assert len(matched) == len(metadata[metadata['TenX.Lane'].eq(f'L{lane}')])
        assert not matched.intersection(seen)
        seen.update(matched)
        counts.update(labels[cell] for cell in matched)
        label_file, bin_file = root/f'lane{lane}.txt', root/f'lane{lane}.bin'
        label_file.write_text(''.join(f'{lookup[labels[cell]] if cell in labels else -1}\n' for cell in ids))
        with subprocess.Popen(['gzip','-dc',str(raw/f'{prefix}.matrix.mtx.gz')], stdout=subprocess.PIPE) as gz:
            subprocess.run([str(root/'aggregate_thp1'),str(len(groups)),str(label_file),str(bin_file),
                            str(len(features)),str(len(ids)),str(gene_count)], stdin=gz.stdout, check=True)
            if gz.wait():
                raise RuntimeError('Matrix decompression failed')
        lane_sums = np.fromfile(bin_file).reshape(len(groups),len(features))[:,:gene_count]
        sums = lane_sums.copy() if sums is None else sums + lane_sums
        bin_file.unlink()
        print(f'Lane {lane}: {len(matched)} matched', flush=True)
    assert seen == set(metadata.index)
    data = sums / np.array([counts[group] for group in groups])[:,None]
    data -= data[lookup[()]].copy()
    np.savez_compressed(root/'thp1_conditions.npz',
                        labels=np.array(['+'.join(group) for group in groups]),
                        count=np.array([counts[group] for group in groups]), responses=data)
    return counts, {group:data[i] for i,group in enumerate(groups)}


def evaluate(counts, data, threshold):
    eligible = sorted(pair for pair,n in counts.items()
                      if len(pair)==2 and n>=threshold and all(counts[(g,)]>=threshold for g in pair))
    pairs = np.array(eligible)
    a,b,y = map(np.stack,([data[(u,)] for u,v in eligible],
                          [data[(v,)] for u,v in eligible],
                          [data[pair] for pair in eligible]))
    add = a+b
    resid, features, mask = y-add,gf.feature_matrix(a,b),gf.panels(a,b)
    genes = np.unique(pairs)
    split_sizes, scores = [], defaultdict(list)
    for seed in range(100,120):
        held = np.random.default_rng(seed).choice(genes,size=round(len(genes)*18/73),replace=False)
        degree = np.isin(pairs,held).sum(axis=1)
        tr,te = np.flatnonzero(degree==0),np.flatnonzero(degree==2)
        split_sizes.append(dict(seed=seed,train=len(tr),test=len(te)))
        if len(te)==0 or len(tr)<5:
            continue
        b3 = gf.Baseline('B3').fit(add[tr],resid[tr],mask[tr])
        base = add[te]+b3.predict(add[te])
        target = np.empty_like(resid[tr])
        for st,sv in KFold(n_splits=5,shuffle=True,random_state=seed).split(tr):
            sub = gf.Baseline('B3').fit(add[tr[st]],resid[tr[st]],mask[tr[st]])
            target[sv] = resid[tr[sv]]-sub.predict(add[tr[sv]])
        scaler = StandardScaler().fit(features[tr])
        xt,xv = scaler.transform(features[tr]),scaler.transform(features[te])
        pca = PCA(n_components=1,svd_solver='full').fit(target)
        pred = Ridge(alpha=100).fit(xt,pca.transform(target)).predict(xv)
        direct = Ridge(alpha=100).fit(xt,target).predict(xv)
        methods = [add[te],base,base+target.mean(axis=0),base+pca.inverse_transform(pred.reshape(-1,1)),base+direct]
        for i, errors in zip(te,np.array([gf._sse(y,p,mask,te) for p in methods]).T):
            scores[tuple(pairs[i])].append(errors)
    keys = ['additive','B3','mean_only','rank_one_PCA_ridge','direct_ridge']
    mean_errors = {p:np.mean(v,axis=0) for p,v in scores.items()}
    pooled = np.stack(list(mean_errors.values())).sum(axis=0)
    with (root/f'thp1_pair_errors_min{threshold}.csv').open('w') as handle:
        writer = csv.writer(handle)
        writer.writerow(['gene_a','gene_b','test_appearances',*keys])
        writer.writerows((*p,len(scores[p]),*mean_errors[p]) for p in sorted(scores))
    return dict(min_cells=threshold, eligible_pairs=len(pairs), heldout_pairs=len(scores),
                heldout_appearances=sum(map(len,scores.values())), control_cells=counts[()],
                additive_relative_r2=dict(zip(keys,1-pooled/pooled[0])),
                rank1_sse_reduction_vs_mean_only=1-pooled[3]/pooled[2], split_sizes=split_sizes)


if __name__ == '__main__':
    counts,data = reconstruct()
    result = [evaluate(counts,data,t) for t in (50,25)]
    rendered = json.dumps(result,indent=2)
    (root/'thp1_validation.json').write_text(rendered+'\n')
    print(rendered,flush=True)
