# GeneRx-FATE independent-dataset replication

This exploratory replication fits the existing GeneRx-FATE architecture within the independently collected Wessels et al. THP-1 CaRPool-seq screen, GEO GSE213957. This experiment assesses whether the approach works with a new dataset and assay (Cas13d RNA knockdown). It does not evaluate zero-shot transfer of a K562-trained model. No GEARS scores are reported here.

## Method

The four GEXGDO Matrix Market files were joined to the authors’ THP-1 cell metadata by lane and barcode. All 30,707 metadata cells matched exactly once. Guide-capture features were excluded from library normalization. The 20,639 RNA features were normalized per cell with 10,000 counts and log1p. We averaged normalized cells within each perturbation label after canonicalizing the two targets and subtracting the mean of 424 nontargeting cells. Primary analysis retained pairs for which the two matching single conditions and the double condition each had at least 50 cells. The 25-cell analysis was a sensitivity check.

Models were trained on combinations containing neither held-out gene and tested on combinations containing two held-out genes, with both matched single-perturbation profiles available at prediction time. Each of seeds 100–119 holds out approximately one quarter of eligible target genes. Splits with no test pairs are skipped and reported. Features, 200-gene panels, cross-fitted B3 residuals, rank-one PCA, ridge penalty of 100, and per-pair-averaged pooled SSE follow the published Norman benchmark implementation. The panel depends on the two single-perturbation profiles. Models and all learned transforms are fit within the THP-1 training splits. The experiment pools lanes and is descriptive; scores do not include replicate-aware uncertainty intervals.

## Results

| Threshold | Eligible combinations | Unique tested combinations | Additive-relative R², mean-only | Additive-relative R², rank-one | Additive-relative R², direct ridge | Rank-one SSE reduction vs mean-only |
|---|---:|---:|---:|---:|---:|---:|
| 50 cells per condition | 58 | 45 | 0.35081 | 0.37666 | 0.37978 | 3.98% |
| 25 cells per condition | 142 | 100 | 0.49804 | 0.50284 | 0.50813 | 0.96% |

Rank-one errors were lower than mean-only on the pooled metric at both thresholds. Direct ridge achieved slightly lower pooled error than rank-one at both thresholds. Each score uses that threshold's own eligible pairs and denominator.

## Reproduce

Download the THP-1 metadata and the GEXGDO archive listed in GSE213957. Save the metadata as `THP1.metadata.tsv.gz` and the archive as `THP1_and_HEK293.tar.gz`, then run from this directory. Provide the published GeneRx-FATE checkout via PYTHONPATH.

```sh
mkdir -p raw
tar -xzf THP1_and_HEK293.tar.gz -C raw --wildcards '*GEXGDO*'
sha256sum -c thp1_input_SHA256SUMS
g++ -O3 aggregate_thp1.cpp -o aggregate_thp1
PYTHONPATH=/path/to/GeneRx-FATE OPENBLAS_NUM_THREADS=2 python external.py
```

The separate file `norman_strict_splits.csv` records the K562 train, test, and excluded combinations for 20 seeds. It supports a future matched GEARS comparison and was not used to train the THP-1 models.
